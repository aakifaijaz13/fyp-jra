from django.apps import AppConfig


class CampusrecruiterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'campusrecruiter'
